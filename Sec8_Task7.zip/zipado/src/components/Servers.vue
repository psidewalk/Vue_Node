<template>
    <div class="col-xs-6 col-sm-6">
        <button class="btn btn-primary" @click="lRandom">
            Click here to launch random states to all servers</button>
        <p></p>
        <app-server-details :idServer="id" :servers="servers" :states="states"></app-server-details>
        <hr>
        <app-footer :idServer="id"></app-footer>
    </div>
</template>

<script>
import ServerDetails from './ServerDetails.vue';
import Footer from './Footer.vue';

export default {
    components: {
        'app-server-details': ServerDetails,
        'app-footer': Footer
    },
    data: function () {
        this.servers = [
            { id: 1, status: 'Normal' },
            { id: 2, status: 'Danger' },
            { id: 3, status: 'Warning' },
            { id: 4, status: 'Danger' },
            { id: 5, status: 'Normal' },
        ];
        return {
            servers: this.servers,
            states: ['Normal', 'Warning', 'Danger'],
            id: 1
        };
    },
    methods: {
        lRandom() {  //forEach é 95% mais lento do que esse for()
            var i = 0;  //if omit this line the button don't work
            for (i = 0; i < 5; i++) {
                this.servers[i].status = this.states[Math.floor(Math.random() * 3)];
            }
        }
    }
}
</script>

<style scoped>

</style>
