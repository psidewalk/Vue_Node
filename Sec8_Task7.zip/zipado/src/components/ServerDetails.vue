<template>
    <div class="col-xs-6 col-sm-6">
        <ul class="list-group">
            <li class="list-group-item" v-for="server in servers">
                Server #{{ server.id + " : " }}
                <span class="label label-success" v-if="server.status == 'Normal'">{{ server.status }}</span>
                <span class="label label-warning" v-if="server.status == 'Warning'">{{ server.status }}</span>
                <span class="label label-danger" v-if="server.status == 'Danger'">{{ server.status }}</span>
            </li>
        </ul>
    </div>
</template>

<script>
//import the eventBus defined in the main.js - from the another Vue instance
import { eventBus } from '../main';

export default {
    props: ['servers', 'states', 'idServer'],
    created() {
        eventBus.$on('changeToNormal', (id) => {
            this.servers[id].status = 'Normal';
        });
    }
}
</script>

<style scoped>
li {
    color: black;
    font-weight: bold;
}
</style>
