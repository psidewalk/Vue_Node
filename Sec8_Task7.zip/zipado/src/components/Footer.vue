<template>
    <div class="row">
        <div class="col-xs-6">
            <footer>
                <p>Click in the respective button to normalize the server</p>
                <div class="btn-group" role="group" aria-label="...">
                    <button type="button" class="btn btn-default" v-for="i in 5" @click="normalize(i)">{{ i }}</button>
                </div>
            </footer>
        </div>
    </div>
</template>

<script>
//import the eventBus defined in the main.js - from the another Vue instance
import { eventBus } from '../main';

export default {
    props: { idServer: Number },
    methods: {
        normalize(id) {
        this.idServer = id - 1;
//        this.$emit('changeToNormal',this.id);
        eventBus.$emit('changeToNormal',this.idServer);
        }    
    }
}

</script>

<style scoped>

button {
  color: red;
  font-weight: bold;       
}

</style>
