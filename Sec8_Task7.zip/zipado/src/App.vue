<template>
    <div class="container">
        <app-header></app-header>
        <hr>
        <div class="row">
            <servers></servers>
        </div>
    </div>
</template>

<script>
import Header from './components/Header.vue';
import Servers from './components/Servers.vue';

export default {
    components: {
        appHeader: Header,
        servers: Servers,
    }
}
</script>

<style>

</style>
