<template>
    <div class="row">
        <div class="col-xs-6">
            <header>
                <h1>Server Status</h1>
            </header>
        </div>
    </div>
</template>

<script>
</script>

<style>
</style>
