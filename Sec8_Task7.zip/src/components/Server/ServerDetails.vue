<template>
    <div class="col-xs-6 col-sm-6">
        <ul class="list-group">
            <li class="list-group-item" v-for="server in servers">
                Server #{{ server.id + " : " }}
                <span class="badge">{{ server.status }}</span>
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    props: ['servers']
}
</script>

<style scoped>
li {
    color: red;
    font-weight: bold;
}

badge {
    background-color: black;
}
</style>
