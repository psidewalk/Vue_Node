<template>
    <div class="col-xs-6 col-sm-6">
        <button class="btn btn-primary" @click="lRandom">Click here to launch random states to all servers</button>
        <p></p>
        <app-server-details :servers="servers"></app-server-details>
    </div>
</template>

<script>
import ServerDetails from './ServerDetails.vue';

export default {
    data: function () {
        this.servers = [
            {id:1, status: 'Normal'},
            {id:2, status: 'Medium'},
            {id:3, status: 'Critical'},
            {id:4, status: 'Critical'},
            {id:5, status: 'Medium'}
        ]
        return {
            servers: this.servers,
            states: ['Normal', 'Medium', 'Critical'],
        };
    },
    methods: {
        lRandom() {  //forEach é 95% mais lento do que esse for()
            for (i = 0; i < this.servers.length; i++) {
                var noStatus = Math.floor(Math.random() * 3);
                this.servers[i].status = states(noStatus);
            }
        }
    },
    components: {
        'app-server-details': ServerDetails
    }
}

</script>

<style scoped>
li {
    color: red;
    font-weight: bold;
}

badge {
    background-color: black;
}
</style>
